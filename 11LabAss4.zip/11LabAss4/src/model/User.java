/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author user
 */
public class User {
    private String Fname;
    private String Lname;
    private String Age ;
    private String Email;
    private String Message;
    private String Type ;
    private String Gender;
    public String setLname;
    
    public String getFname(){
    return Fname;
    }
    public void setFname(String Fname){
        this.Fname = Fname;
      }
    public String getLname(){
    return Lname;
    }
    public void setLname(String Lname){
    this.Lname = Lname;
    }
    public String getAge(){
    return Age;
    }
    public void setAge(String Age){
    this.Age = Age;
    }
    public String getEmail(){
    return Email;
    }
    public void setEmail(String Email){
    this.Email= Email;
    }
     public String getMessage(){
     return Message;
     }
    public void getMessage(String Message){
    this.Message = Message;
    }
    public String getType(){
    return Type;
    }
    public void setType(String Type){
    this.Type = Type;
    }
    public String getGender(){
    return Gender;
    }
    public void setGender(String Gender){
    this.Gender = Gender;
    }

    public void setMessage(String text) {
         // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
